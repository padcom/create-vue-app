/* eslint-env node */

module.exports = {
  extends: [
    '@padcom/vue',
  ],
}
