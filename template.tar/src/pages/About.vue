<template>
  <PageHeader>About page</PageHeader>
  Go to <Link to="/">Home</Link> page..
</template>
