<template>
  <h1 class="app-header">Vue.js with friends!</h1>
</template>

<style lang="postcss">
.app-header {
  @apply text-center text-5xl;
  @apply mt-5 mb-10;
}
</style>
