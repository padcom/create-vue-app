<template>
  <h2 class="page-header"><slot /></h2>
</template>

<style lang="postcss">
.page-header {
  @apply mb-10 text-3xl;
}
</style>
